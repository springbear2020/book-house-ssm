create definer = root@localhost view v_book as
select `panda`.`t_book`.`id`              AS `id`,
       `panda`.`t_book`.`title`           AS `title`,
       `panda`.`t_book`.`author`          AS `author`,
       `panda`.`t_book`.`translator`      AS `translator`,
       `panda`.`t_book`.`downloads`       AS `downloads`,
       `panda`.`t_book`.`upload_username` AS `upload_username`,
       `panda`.`t_book`.`upload_time`     AS `upload_time`,
       `panda`.`t_book`.`cover_path`      AS `cover_path`,
       `panda`.`t_book`.`comments`        AS `comments`
from `panda`.`t_book`;

-- comment on column v_book.id not supported: 图书 id

-- comment on column v_book.title not supported: 书名

-- comment on column v_book.author not supported: 作者

-- comment on column v_book.translator not supported: 译者

-- comment on column v_book.downloads not supported: 下载量

-- comment on column v_book.upload_username not supported: 上传用户名

-- comment on column v_book.upload_time not supported: 上传时间

-- comment on column v_book.cover_path not supported: 封面保存路径

-- comment on column v_book.comments not supported: 图书评价

